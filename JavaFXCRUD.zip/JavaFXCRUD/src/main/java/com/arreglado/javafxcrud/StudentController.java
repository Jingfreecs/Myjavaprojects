/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.arreglado.javafxcrud;
import com.arreglado.javafxcrud.data.AppQuery;
import com.arreglado.javafxcrud.model.Student;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author user1
 */
public class StudentController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        showStudents();
    }    
    
    @FXML
    public  TextField fieldFirstName;
    @FXML
    public TextField fieldMiddleName;
    @FXML
    public TextField fieldLastName;
    @FXML
    public Button btnNew;
    @FXML
    public Button btnSave;
    @FXML
    public Button btnUpdate;
    @FXML
    public Button btnDelete;
    @FXML
    public TableView tableview;
    @FXML
    public TableColumn<Student, Integer>colId;
    @FXML
    public TableColumn<Student, String>colFirstname;
    @FXML
    public TableColumn<Student, String>colMiddlename;
    @FXML
    public TableColumn<Student, String>colLastname;
    
    @FXML
    private void addStudent()
    {
        com.arreglado.javafxcrud.model.Student student = new com.arreglado.javafxcrud.model.Student(fieldFirstName.getText(),fieldMiddleName.getText(),fieldLastName.getText());
        com.arreglado.javafxcrud.data.AppQuery query = new AppQuery();
        query.addStudent(student);
    }
    @FXML
    public void showStudents()
    {
        com.arreglado.javafxcrud.data.AppQuery query = new  com.arreglado.javafxcrud.data.AppQuery();
        ObservableList<Student> list = query.getStudentList();
        colId.setCellValueFactory(new PropertyValueFactory<Student, Integer>("id"));
        colFirstname.setCellValueFactory(new PropertyValueFactory<Student, String>("firstname"));
        colMiddlename.setCellValueFactory(new PropertyValueFactory<Student, String>("middlename"));
        colLastname.setCellValueFactory(new PropertyValueFactory<Student, String>("lastname"));
        tableview.setItems(list);
    }
    
}
