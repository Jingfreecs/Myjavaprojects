/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.arreglado.javafxcrud.data;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author user1
 */
public class AppQuery {
    private DBConnection c = new DBConnection();
    
    public void addStudent(com.arreglado.javafxcrud.model.Student student){
        try{
            c.getDBConn();
            java.sql.PreparedStatement ps = c.getCon().prepareStatement("INSERT INTO students(firstname,middlename,lastname)values(?,?,?)");
            ps.setString(1,student.getFirstname());
            ps.setString(2,student.getMiddlename());
            ps.setString(3,student.getLastname());
            ps.execute();
            ps.close();
            c.closeConnection();
        }catch(SQLException e){
            e.printStackTrace();
        }
    }
    public ObservableList<com.arreglado.javafxcrud.model.Student> getStudentList()
    {
        ObservableList<com.arreglado.javafxcrud.model.Student> studentList = FXCollections.observableArrayList();
        try{
            String query = "select id,firstname,middlename,lastname from students order by lastname asc";
            c.getDBConn();
            Statement st = c.getCon().createStatement();
            ResultSet rs = st.executeQuery(query);
            com.arreglado.javafxcrud.model.Student s;
            while(rs.next()){
                s = new com.arreglado.javafxcrud.model.Student(rs.getInt("id"),rs.getString("firstname"),rs.getString("middlename"),rs.getString("lastname"));
                studentList.add(s);
            }
            rs.close();
            st.close();
            c.closeConnection(); 
        }catch(Exception e){
            e.printStackTrace();
        }
        return studentList;
    }
}
