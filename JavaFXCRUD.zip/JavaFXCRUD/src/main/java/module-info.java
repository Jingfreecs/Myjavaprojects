module com.arreglado.javafxcrud {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;
    requires java.sql;
    


    opens com.arreglado.javafxcrud to javafx.fxml;
    exports com.arreglado.javafxcrud;
    exports com.arreglado.javafxcrud.data;
    exports com.arreglado.javafxcrud.model;
}
